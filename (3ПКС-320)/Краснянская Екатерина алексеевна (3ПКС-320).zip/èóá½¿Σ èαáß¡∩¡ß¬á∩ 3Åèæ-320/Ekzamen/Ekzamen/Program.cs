﻿using Turistt;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Turistt { 
    class Turist
    {
        
        private string surname; //  фамилия туриста 
        private List<int> routes; // коллекция маршрутов

        
        public string Surname { get => surname; } //делаем фамилию доступной

     
        public List<int> Routes { get => routes; } //делаем маршруты доступными

 
        public Turist(string surname) //конструктор для создания фамилии туриста и объявлении коллекции маршрутов
        {
            this.surname = surname;
            this.routes = new List<int>();
        }

        // Constructor to create a turist with a surname and a list of routes 
        //public Turist(string surname, string routes) //конструктор для создания фамилии и присваивания коллекции маршрутов значения
        //{
        //    this.surname = surname;
        //    this.routes = ParseRoutes(routes);
        //}

        private List<int> ParseRoutes(string routes) //метод заполнения коллекции
        {
            try
            {
                 
                return routes.Split(',').Select(int.Parse).ToList();
            }
            catch (FormatException)
            { 
                return new List<int>();
            }
        }

        public int CalculateTotal() //метод вычисления суммы маршрутов 
        {
            return routes.Sum();
        }
        public int CalculateRoutes() //метод возвращающий колличество маршрутов
        {
            return routes.Count();
        }


         public double CalculateAverage() // расчет среднего арифметического 
        {
            
            if (routes.Count == 0)
            {
                return 0;
            }

            return (double)CalculateTotal() / routes.Count;
        }
    }

}

class Program
{
    static void Main(string[] args)
    {
        //Console.WriteLine("Введите фамилию первого туриста"); string name1 = Console.ReadLine();
        //Console.WriteLine("Введите фамилию второго туриста"); string name2 = Console.ReadLine();
        //Console.WriteLine("Введите фамилию третьего туриста"); string name3 = Console.ReadLine();
        List<Turist> turists = new List<Turist>(); //коллекция туристов
        //туристы 
        turists.Add(new Turist("Иванов")); 
        turists.Add(new Turist("Петров"));
        turists.Add(new Turist("Сидоров"));

        Random random = new Random();//подключение рандома

        foreach (Turist turist in turists) //генерация колличества маршрутов и их значений 
        {
            for (int i = 0; i < random.Next(1, 11); i++)
            {
                turist.Routes.Add(random.Next(1, 40001));
            }
        }
        foreach (Turist turist in turists) //вывод данных в консоль и в файл
        {


            Console.WriteLine("Маршруты туриста " + turist.Surname + ": " + string.Join(", ", turist.Routes));
            Console.WriteLine("среднии маршрут : " + Math.Round(turist.CalculateAverage(), 2));
            try
            {
                FileInfo fileInfo = new FileInfo(@"D:\пп\Krasnaynskay.txt");
                StreamWriter sw = fileInfo.AppendText();

                sw.WriteLine("Маршруты туриста " + turist.Surname + ": " + string.Join(", ", turist.Routes));
                sw.WriteLine("среднии маршрут : " + Math.Round(turist.CalculateAverage(), 2));
                //sw.WriteLine("Кол-во положительных оценок ");

                sw.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }

        }
        

        //int numFives = turists.Sum(turist => turist.Routes.Count(grade => grade == 5));
        //int numFours = turists.Sum(turist => turist.Routes.Count(grade => grade == 4));
        //int numFours1 = turists.Sum(turist => turist.Routes.Count());
        //Console.WriteLine(numFives);
        //Console.WriteLine(numFours);
        //Console.WriteLine(numFours1);
        //double percentage = (numFives + numFours) * 100 / numFours1;

        // Display the percentage on the screen 
        //Console.WriteLine("Percentage of knowledge quality: " + percentage + "%");
       
        Console.ReadLine();
    }
}
