﻿#include <Windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cmath> // для round
using namespace std;

class Student
{
	string name, otzenki;
public:
	Student(string _name)
	{
		name = _name;
	}
	Student(string _name, string _otzenki)
	{
		name = _name;
		otzenki = _otzenki;
	}
	void showOzenki()
	{
		cout << "\n";
		cout << "Оценки студента: " + name << endl;
		for (int i = 0; i < otzenki.size(); i++)
		{
			if (otzenki[i] != ',')
			{
				cout << otzenki[i];
				if (i < otzenki.size() - 2)
					cout << ",";

			}
		}
		cout << "\n\n";
	}
};
int getRandomNum(int min, int max)
{
	int range = max - min + 1;
	srand((int)time(0));
	return rand() % range + min;
}
int sumOtzenki(int otzenki[], int len)
{
	int res = 0;
	__asm
	{
		mov ecx, len //записываем длину массива
		mov esi, otzenki //записываем оценки
		cycl :
		mov eax, [esi]
			push ecx
			add res, eax
			pop ecx
			add esi, 4
			loop cycl
	}
	return res;
}
int stats(int hrsh, int otl, int totalStudentsAmount)
{
	int res = 0;
	__asm
	{
		mov eax, hrsh
		add eax, otl
		div totalStudentsAmount
		mov res, eax
	}
	return res;
}
int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	vector<Student> students;
	string name, otzenki;
	int hrsh = 0;
	int otl = 0;
	ofstream myfile("blonkot.txt");
	for (int i = 0; i < 3; i++)
	{
		int countOtzenki = getRandomNum(1, 10);
		cout << "\n\n\tФамилия студента номер " << i + 1 << ": "; cin >> name;
		otzenki = "";
		int otzenkiSum[10];
		for (int j = 0; j < countOtzenki; j++)
		{
			int otzenka = getRandomNum(2, 5);
			otzenki += to_string(otzenka) + ',';
			otzenkiSum[j] = otzenka;
			if (otzenka == 4)
			{
				hrsh++;
			}
			if (otzenka == 5)
			{
				otl++;
			}
			Sleep(175);
		}
		students.push_back(Student(name, otzenki));
		students.back().showOzenki();
		float sredOtzenka = sumOtzenki(otzenkiSum, countOtzenki) / (float)countOtzenki;
		sredOtzenka = round(sredOtzenka * 100) / 100;
		cout << "Ср. балл студента: " << sredOtzenka << endl << endl;
		myfile << name << " " << otzenki << " Ср. балл студента: " << sredOtzenka << endl;
	}
	int stt = stats(hrsh, otl, students.size());
	cout << stt << "% - качество знаний";
	myfile << stt << "% - качество знаний";
	myfile.close();
}
