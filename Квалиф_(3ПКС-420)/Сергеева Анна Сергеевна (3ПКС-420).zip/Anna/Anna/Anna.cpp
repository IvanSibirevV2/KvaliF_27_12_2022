﻿#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <Windows.h>
using namespace std;
#define ARR_SIZE 3


class Sotrudnik  //Создан класс "Сотрудник"
{
public:
    string name;
    int salaries[10];  
    int s;
    Sotrudnik() {}
    Sotrudnik(string _name)
    {
        name = _name;
    }
    Sotrudnik(string _name, int _salaries[])
    {
        name = _name;
        memcpy(_salaries, salaries, sizeof salaries);
    }

};

int getRandom(int max, int min)      //Формирование зарплат рандомом
{
    int range = max - min + 1;

    return rand() % range + min;

}

string allSalaries10(Sotrudnik currSotrudnik)     
{
    string str = "";
    for (int i = 0; i < 10; i++)
    {
        str += to_string(currSotrudnik.salaries[i]);
        if (i != 10 - 1)
        {
            str += ", ";
        }
        else
        {
            str += ";";
        }
    }
    return str;
}

string allSalaries6(Sotrudnik currSotrudnik)
{
    string str = "";
    for (int i = 0; i < 6; i++)
    {
        str += to_string(currSotrudnik.salaries[i]);
        if (i != 6 - 1)
        {
            str += ", ";
        }
        else
        {
            str += ";";
        }
    }
    return str;
}

void info_out(Sotrudnik currSotrudnik)
{
    cout << currSotrudnik.name << ":";
    cout << allSalaries10(currSotrudnik);
    cout << endl;
}

double average(Sotrudnik currSotrudnik)
{
    double res;
    unsigned int result = 0;
    _asm
    {
        XOR EAX, EAX
        XOR ECX, ECX
        MOV ECX, 0
        BEGIN:
        ADD EAX, currSotrudnik.salaries[ECX * 4]
            INC ECX
            CMP ECX, 6
            JL BEGIN
            XOR BX, BX
            XOR CX, CX
            MOV result, EAX
    }
    res = (double)result / 6;
    cout << res << endl;
    return res;
}


int main()
{
    srand((unsigned int)time(NULL));
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    Sotrudnik s1, s2, s3;
    s1.name = "Сергеев за 10 мес";
    s2.name = "Разуков за 10 мес";
    s3.name = "Порцин за 10 мес";

    for (int i = 0; i < 10; i++) {
        s1.salaries[i] = getRandom(60000, 40000);
        s2.salaries[i] = getRandom(60000, 40000);
        s3.salaries[i] = getRandom(60000, 40000);
    }
    info_out(s1);
    info_out(s2);
    info_out(s3);
    cout << endl;
    double avS1 = average(s1);
    double avS2 = average(s2);
    double avS3 = average(s3);
    cout << endl;
    cout << "Ср з/п за 6 мес " + s1.name + "а: " << avS1 << endl;
    cout << "Ср з/п за 6 мес " + s2.name + "а: " << avS2 << endl;
    cout << "Ср з/п за 6 мес " + s3.name + "а: " << avS3 << endl;
    std::ofstream out;
    out.open("C:/Users/206936/Desktop/Сотрудники");
    if (out.is_open())
    {
        out << s1.name << endl;
        out << "З/п за 6 месяцев: " << allSalaries6(s1) << endl;
        out << "Ср размер з/п: " << avS1 << endl;
        out << "--------------------------------------------------------" << endl;
        out << s2.name << endl;
        out << "З/п за 6 месяцев: " << allSalaries6(s2) << endl;
        out << "Ср размер з/п: " << avS2 << endl;
        out << "--------------------------------------------------------" << endl;
        out << s3.name << endl;
        out << "З/п за 6 месяцев: " << allSalaries6(s3) << endl;
        out << "Ср размер з/п: " << avS3 << endl;
        out << "--------------------------------------------------------" << endl;

    }
    system("pause");
    return 0;
}
