﻿using System;
using System.Collections.Generic;
using System.Linq;
using Binarysharp.Assemblers.Fasm;
using Process.NET;
using Process.NET.Native.Types;
using System.Runtime.InteropServices;
using System.Security;
using System.IO;

namespace ConsoleApp1
{

    public class Worker  //класс Сотрудник
    {
        public string Surname;       //фамилия сотрудника
        public Dictionary<int, int> Month_salary = new Dictionary<int, int>();      //коллекция зарплат по номеру месяца
        //public List<System.Int32> LabS = new List<System.Int32>();
        public int[] mass = new int[10];

        public Worker(string surname)
        {
            Surname = surname;
        }

        public Worker(string surname, int[] str_salary)
        {
            mass = str_salary;
            Surname = surname;
            int[] str = str_salary;
            for (int i = 0; i < str.Length; i++)
            {
                Month_salary.Add(i + 1, str[i]);
            }
        }
        public void Print() //метода вывода заполненной информации о сотруднике
        {
            Console.WriteLine("\n\tФамилия сотрудника: " + Surname);
            for (int i = 0; i < Month_salary.Count; i++)
                Console.WriteLine($"\t\t\tМесяц: {Month_salary.ElementAt(i).Key}\tЗарплата: {Month_salary.ElementAt(i).Value}");
        }
        public int Summ()
        {
            int a = 0;
            ;
            if (!false)
            {
                FasmNet _FasmNet = new FasmNet();
                _FasmNet.AddLine("use32");
                _FasmNet.AddLine("xor eax, eax");
                _FasmNet.AddLine("xor ebx, ebx");
                _FasmNet.AddLine("xor ecx, ecx");
                _FasmNet.AddLine("mov ebx, dword [ebp+12]");
                _FasmNet.AddLine("sum:");
                _FasmNet.AddLine("add eax, dword [ebx+ecx*4]");
                _FasmNet.AddLine("add ecx, 1");
                _FasmNet.AddLine("cmp ecx, dword [ebp+8]");
                _FasmNet.AddLine("jne sum");
                _FasmNet.AddLine("ret");
                System.Byte[] _ByteS = _FasmNet.Assemble();

                Process.NET.Memory.IAllocatedMemory _IAllocatedMemory =
                    new ProcessSharp(System.Diagnostics.Process.GetCurrentProcess(), Process.NET.Memory.MemoryType.Local)
                .MemoryFactory
                .Allocate(
                    name: "MyName",
                    size: _ByteS.Length,
                    protection: MemoryProtectionFlags.ExecuteReadWrite
                );
                _IAllocatedMemory.Write(0, _ByteS);

                delAssemb_sum del_sum = Marshal.GetDelegateForFunctionPointer<delAssemb_sum>(_IAllocatedMemory.BaseAddress);

                a = del_sum(mass.Length - 1, mass);
                _IAllocatedMemory.Dispose();
                ;
            }
            return a;
        }
        [System.Security.SuppressUnmanagedCodeSecurityAttribute]
        [System.Runtime.InteropServices.UnmanagedFunctionPointerAttribute(System.Runtime.InteropServices.CallingConvention.Cdecl)]
        public delegate int delAssemb_sum(int _count, params int[] _ints);
        public int Summ(int _count, params int[] _ints)
        {
            ;
            int qwds = _ints[1];
            int _summ = 0;
            int i = 0;
            while (i < _count)
            {
                int a = _ints[i];
                _summ = _summ + a;
                i++;
            }
            return _summ;
        }

        public int Middle()
        {
            int a = 0;
            ;
            if (!false)
            {
                FasmNet _FasmNet = new FasmNet();
                _FasmNet.AddLine("use32");
                _FasmNet.AddLine("xor eax, eax");
                _FasmNet.AddLine("xor ebx, ebx");
                _FasmNet.AddLine("xor ecx, ecx");
                _FasmNet.AddLine("mov ebx, dword [ebp+12]");
                _FasmNet.AddLine("sum:");
                _FasmNet.AddLine("add eax, dword [ebx+ecx*4]");
                _FasmNet.AddLine("add ecx, 1");
                _FasmNet.AddLine("cmp ecx, dword [ebp+8]");
                _FasmNet.AddLine("jne sum");
                _FasmNet.AddLine("ret");
                System.Byte[] _ByteS = _FasmNet.Assemble();

                Process.NET.Memory.IAllocatedMemory _IAllocatedMemory =
                    new ProcessSharp(System.Diagnostics.Process.GetCurrentProcess(), Process.NET.Memory.MemoryType.Local)
                .MemoryFactory
                .Allocate(
                    name: "MyName",
                    size: _ByteS.Length,
                    protection: MemoryProtectionFlags.ExecuteReadWrite
                );
                _IAllocatedMemory.Write(0, _ByteS);

                delAssemb_sum del_sum = Marshal.GetDelegateForFunctionPointer<delAssemb_sum>(_IAllocatedMemory.BaseAddress);

                a = del_sum(mass.Length - 1, mass);
                _IAllocatedMemory.Dispose();
                ;
            }
            return a/mass.Length;
        }
    }


    public class Program
    {
        static void Main(string[] args)
        {
            Worker worker1 = new Worker("Капская", random_salary());
            worker1.Print();
            Worker worker2 = new Worker("Попов");
            worker2.Print();
            Worker worker3 = new Worker("Альшакова", random_salary());
            worker3.Print();

			Console.WriteLine("\nОбщая сумма зарплаты Капской: ");
            System.Console.WriteLine(worker1.Summ());
            Console.WriteLine("Средняя сумма зарплаты Капской: ");
            System.Console.WriteLine(worker1.Middle());

            Console.WriteLine("\nОбщая сумма зарплаты Попова: ");
            System.Console.WriteLine(worker2.Summ());
            Console.WriteLine("Средняя сумма зарплаты Попова: ");
            System.Console.WriteLine(worker2.Middle());

            Console.WriteLine("\nОбщая сумма зарплаты Альшаковой: ");
            System.Console.WriteLine(worker3.Summ());
            Console.WriteLine("Средняя сумма зарплаты Альшаковой: ");
            System.Console.WriteLine(worker3.Middle());

            System.Console.ReadLine();


            int[] random_salary() //метод формирует зарплаты генератором случайных чисел 
            {
                Random rand = new Random();
                int n = 10; 
                int[] mass_salary = new int[n];
                for (int i = 0; i < mass_salary.Length; i++)
                {
                    mass_salary[i] = rand.Next(40000, 60001); //зарплата сотрудника в диапазоне от 40 000 до 60 000
                }

                return mass_salary;
            }
        }
    }
}
