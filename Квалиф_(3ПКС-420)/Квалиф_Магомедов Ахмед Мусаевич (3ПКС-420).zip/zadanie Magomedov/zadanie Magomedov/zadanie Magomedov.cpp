﻿#include <iostream> 
#include <string>
#include <cstdlib> //Для записи рандома
#include <fstream> //Для записи в файл
#include <Windows.h>
#include <cmath> //Для round
#include <ctime> //Для time

using namespace std;

class Tourist
{
    public:
        string kilometr;
        string fam;
        int kilometers[9]; //Массив маршрутов
        Tourist(string fam1)
        {
            fam = fam1;
        }
       Tourist(string fam1, string kilometr1)
        {
            fam = fam1;
            kilometr = kilometr1;
        }
};
int RandomNumbers() {
    return 1 + rand() % 40;\
}

string ToStringKilometers(Tourist tourist)
{
    string str = "";
    for (int i = 0; i < 9; i++)
    {
        str += to_string(tourist.kilometers[i]); //Преобразование числа в строку
        if (i != 9 - 1)
        {
            str += ",";
        }
        else
        {
            str += ",";
        }
    }
    return str;
}
void output(Tourist tourist)
{
    cout << tourist.fam << " ";
    cout << ToStringKilometers(tourist);
    cout << endl << "=====";
    cout << endl;
}

double avg(Tourist tourist)
{
    double avg;
    unsigned int sum = 0;
    _asm
    {
        xor eax, eax
        xor ecx, ecx
        mov ecx, 0
        metka :
        add eax, tourist.kilometers[ecx * 4]
            inc ecx
            cmp ecx, 9
            jl metka
            xor bx, bx
            xor cx, cx
            mov sum, eax
    }
    avg = (double)sum / 9;
    cout << round(avg * 100) / 100 << endl;
    return avg;

}


int main()
{
    srand((unsigned int)time(NULL));
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    string sur1, sur2, sur3;
    cout << "Введите фамилию первого туриста: ";
    cin >> sur1;
    cout << "Введите фамилию второго туриста: ";
    cin >> sur2;
    cout << "Введите фамилию третьего туриста: ";
    cin >> sur3;
    Tourist FIRSTtourist(sur1), SECONDtourist(sur2), THIRDtourist(sur3);

    for (int i = 0; i < 9; i++) {
        FIRSTtourist.kilometers[i] = RandomNumbers();
        SECONDtourist.kilometers[i] = RandomNumbers();
        THIRDtourist.kilometers[i] = RandomNumbers();
    }

    output(FIRSTtourist);
    output(SECONDtourist);
    output(THIRDtourist);
    double avg1 = avg(FIRSTtourist);
    double avg2 = avg(SECONDtourist);
    double avg3 = avg(THIRDtourist);

    cout << "--------------------------------------" << endl;
    cout << " Среднее растояние, которое прошёл турист " + FIRSTtourist.fam + ":" << round(avg1) << endl << "=====" << endl;
    cout << " Среднее растояние, которое прошёл турист " + SECONDtourist.fam + ":" << round(avg2 * 100) / 100 << endl << "=====" << endl;
    cout << " Среднее растояние, которое прошёл турист " + THIRDtourist.fam + ":" << round(avg3 * 100) / 100 << endl << "=====" << endl;


    ofstream file; //Запись файла 
    file.open("C:\\Users\\magfa\\source\\repos\\zadanie Magomedov\\file.txt"); //Открытие файла 
    if (file)
    {
        string division = "--------------------------------------";
        file << FIRSTtourist.fam << endl;
        file << "Пройденные километры: " << ToStringKilometers(FIRSTtourist) << endl;
        file << "Среднее пройденное расстояние: " << round(avg1 * 100) / 100 << endl;
        file << division << endl;
        file << SECONDtourist.fam << endl;
        file << "Пройденные километры: " << ToStringKilometers(SECONDtourist) << endl;
        file << "Среднее пройденное расстояние: " << round(avg2 * 100) / 100 << endl;
        file << division << endl;
        file << THIRDtourist.fam << endl;
        file << "Пройденные километры: " << ToStringKilometers(THIRDtourist) << endl;
        file << "Среднее пройденное расстояние: " << round(avg3 * 100) / 100 << endl;
        file << division << endl;
    }

    else
    {
        cout << "Ошибка при открытии файла!";
    }

    file.close();
    system("pause");
    return 0;
}


    
