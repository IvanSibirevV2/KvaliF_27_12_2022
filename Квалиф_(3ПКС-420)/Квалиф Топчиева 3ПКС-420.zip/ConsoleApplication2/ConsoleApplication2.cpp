﻿#include <Windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <ctime>
using namespace std;
#define ARR_SIZE 3


class Worker//создание класса
{
    string surname, salary;

public:

    Worker();
    Worker(string _surname)
    {
        surname = _surname;
    }
    Worker(string _surname, string _salary)
    {
        surname = _surname;
        salary = _salary;
    }
    void displaySalary()//выод заработной платы
    {
        cout << "-------------------------\n";
        cout << "Зарплата работника " + surname+": ";
        for (int i = 0; i < salary.size(); i++)
        {
            cout << salary[i];

        }
        cout << "\n-------------------------\n";
    }
};
int getRandomNum(int min, int max)//метод для получения ранодомных значений в опередленных границах
{
    int range = max - min + 1;
    return rand() % range + min;
}
 double getSalarySum(int salary[], int len)//метод для нахождения среднего
{
    double res;
    unsigned int result = 0;
    __asm//ассемблерная вставка
    {
        mov ecx, len
        mov esi, salary
        cycl :
        mov eax, [esi]
            push ecx
            add result, eax
            pop ecx
            add esi, 4
            loop cycl
    }

    res = (double)result / len;
    
    return res;
}
string allSalaries6(int _salary[],int _salaryCount)//возварщает строку с з/п за 6 мес
{
    string salary = "";
 
    
    for (int i = 0; i < 6; i++)
    {
        
        if (i> _salaryCount-1) { _salary[i] = 0; }
        salary += to_string(_salary[i]);
        if (i != 5)
        {
            salary += ", ";
        }
        else
        {
            salary += ";";
        }
    }
    return salary;
}


int main()
{
    srand((unsigned int)time(NULL));
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    vector<Worker> workes;//объявление вектора
    string surname, salary;
    std::ofstream out;
    out.open("Сотрудники.txt");

    for (int i = 0; i < 3; i++)
    {
        int salaryCount = getRandomNum(1, 10);
        cout << "\nВведите фамилию сотрудника " << ": "; cin >> surname;
        salary = "";
        int salaryToSum[10];
        for (int j = 0; j < salaryCount; j++)
        {
            int sal = getRandomNum(40000, 60000);
            salary += to_string(sal);

            if (j != salaryCount - 1)
            {
                salary += ", ";
            }
            else
            {
                salary += ";";
            }
            salaryToSum[j] = sal;

        }

        workes.push_back(Worker(surname, salary));//добавление в коллекцию
        workes.back().displaySalary();//просмотр последней ячейки
        cout << "Средняя зарплата: ";
        double s = round(getSalarySum(salaryToSum, salaryCount) * 100) / 100;
        cout << s << endl;
        if (out.is_open())//ввод занчений в файл
        {

            out << surname << endl;
            out << "Зарабатаная плата за 6 месяцев: " << allSalaries6(salaryToSum,salaryCount)<< endl;
            out << "Средний размер зарплаты: " << s << endl;
            out << "----------------------------------" << endl;

        }



    }
   

}
