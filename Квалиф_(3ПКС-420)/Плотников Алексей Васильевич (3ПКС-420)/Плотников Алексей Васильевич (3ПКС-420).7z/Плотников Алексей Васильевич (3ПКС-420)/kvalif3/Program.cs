﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Binarysharp.Assemblers.Fasm;
using Process.NET;
using Process.NET.Native.Types;
using System.Runtime.InteropServices;
using System.Security;
using System.Text.RegularExpressions;
using System.IO;
using System.Diagnostics;

namespace ConsoleApp1
{
    public class Student //студент и есть студент
    {



        string Surame = " ";
        List<int> Grade = new List<int>();

        public Student(string surname, string grade)
        {
            this.Surame = surname;
            this.Grade = grade.Split(',').Select(x => int.Parse(x)).ToList(); //переводим строку в список и записываем в наши оценочки
        }

        public List<int> AccessGrade() //возвращает наши оценочки в код
        {
            return Grade;
        }

        public string surname() //возвращает фамилию в код
        {
            return this.Surame;
        }

        public Student WriteThis() //печатает инфу о студенте на экран+ записывает определенные данные в файл
        {

            Console.WriteLine(this.Surame + ":");
            File.AppendAllText(Program.path, this.Surame + ":\n"); //команда записи в файл, в аргументах путь по которому создать файл и сам текст
            Console.Write("\tОценки: ");
            File.AppendAllText(Program.path, "\tОценки: ");
            foreach (int a in this.Grade) { Console.Write(a + ";"); File.AppendAllText(Program.path, a.ToString() + ';'); };
            // File.AppendAllText(path, "\n");
            return this;
        }

        public int Summ() //Сумма оценок 
        {
            int answer = 0;
            if (!false)
            {
                FasmNet _FasmNet = new FasmNet();

                _FasmNet.AddLine("use32");
                _FasmNet.AddLine("xor eax, eax");
                _FasmNet.AddLine("xor ebx, ebx");
                _FasmNet.AddLine("xor ecx, ecx");
                _FasmNet.AddLine("mov ebx, dword [ebp+12]");
                _FasmNet.AddLine("_start:");
                _FasmNet.AddLine("add eax, dword [ebx]");
                _FasmNet.AddLine("add ebx, 4");
                _FasmNet.AddLine("add ecx, 1");
                _FasmNet.AddLine("cmp ecx, dword [ebp+8]");
                _FasmNet.AddLine("je _end");
                _FasmNet.AddLine("jmp _start");
                _FasmNet.AddLine("_end:");
                _FasmNet.AddLine("ret");
                byte[] _ByteS = _FasmNet.Assemble();

                Process.NET.Memory.IAllocatedMemory _IAllocatedMemory = new ProcessSharp(System.Diagnostics.Process.GetCurrentProcess(), Process.NET.Memory.MemoryType.Local).MemoryFactory.Allocate(
                    name: "SamName",
                    size: _ByteS.Length,
                    protection: MemoryProtectionFlags.ExecuteReadWrite); //работа с памятью

                _IAllocatedMemory.Write(0, _ByteS);

                delSumm _delSumm = Marshal.GetDelegateForFunctionPointer<delSumm>(_IAllocatedMemory.BaseAddress);
                answer = _delSumm(this.Grade.Count, this.Grade.ToArray()); //передаем управление ассемблерной функции с переданными аргументами

                _IAllocatedMemory.Dispose();
            }
            return answer;
        }
        [SuppressUnmanagedCodeSecurity]
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]//отключение безопасности
        public delegate int delSumm(int _count, params int[] _ints);
    }

    public class Program
    {
        public static string path = @"C:\Students information.txt"; //статическое поле хранения файла
        [SuppressUnmanagedCodeSecurity]
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate int delegateDel(int _A, int _B);
        public delegate int delSumm(int _count, int _ints);

        public static int WholePartNumber(int _A, int _B) // высчитать Целую часть числа
        {
            int answer = 0;

            FasmNet _FasmNet = new FasmNet();
            _FasmNet.AddLine("use32");
            _FasmNet.AddLine("xor eax, eax");
            _FasmNet.AddLine("mov eax, dword [ebp+8]");
            _FasmNet.AddLine("cdq");
            _FasmNet.AddLine("idiv dword [ebp+12]");
            _FasmNet.AddLine("ret");
            byte[] _ByteS = _FasmNet.Assemble();

            Process.NET.Memory.IAllocatedMemory _IAllocatedMemory = new ProcessSharp(System.Diagnostics.Process.GetCurrentProcess(), Process.NET.Memory.MemoryType.Local).MemoryFactory.Allocate(
                name: "SamName2",
                size: _ByteS.Length,
                protection: MemoryProtectionFlags.ExecuteReadWrite);

            _IAllocatedMemory.Write(0, _ByteS);

            delegateDel _delSumm = Marshal.GetDelegateForFunctionPointer<delegateDel>(_IAllocatedMemory.BaseAddress);
            answer = _delSumm(_A, _B);

            _IAllocatedMemory.Dispose();
            return answer;
        }

        public static int DecimalPartNumber(int _A, int _B) // высчитать Десятичную часть числа
        {
            int answer = 0;

            FasmNet _FasmNet = new FasmNet();
            _FasmNet.AddLine("use32");
            _FasmNet.AddLine("xor eax, eax");
            _FasmNet.AddLine("mov eax, dword [ebp+8]");
            _FasmNet.AddLine("cdq");
            _FasmNet.AddLine("idiv dword [ebp+12]");
            _FasmNet.AddLine("mov eax, edx");
            _FasmNet.AddLine("ret");
            byte[] _ByteS = _FasmNet.Assemble();

            Process.NET.Memory.IAllocatedMemory _IAllocatedMemory = new ProcessSharp(System.Diagnostics.Process.GetCurrentProcess(), Process.NET.Memory.MemoryType.Local).MemoryFactory.Allocate(
                name: "SamName2",
                size: _ByteS.Length,
                protection: MemoryProtectionFlags.ExecuteReadWrite);
            _IAllocatedMemory.Write(0, _ByteS);

            delegateDel _delSumm = Marshal.GetDelegateForFunctionPointer<delegateDel>(_IAllocatedMemory.BaseAddress);
            answer = _delSumm(_A, _B);

            _IAllocatedMemory.Dispose();
            return answer;
        }

        public static int high_Perfomance(int _A, int _B) // вычислить качественную успеваемость
        {
            int answer = 0;

            FasmNet _FasmNet = new FasmNet();
            _FasmNet.AddLine("use32");
            _FasmNet.AddLine("xor eax, eax");
            _FasmNet.AddLine("mov eax, dword [ebp+12]");
            _FasmNet.AddLine("cdq");
            _FasmNet.AddLine("idiv dword [ebp+8]");
            _FasmNet.AddLine("ret");
            byte[] _ByteS = _FasmNet.Assemble();

            Process.NET.Memory.IAllocatedMemory _IAllocatedMemory = new ProcessSharp(System.Diagnostics.Process.GetCurrentProcess(), Process.NET.Memory.MemoryType.Local).MemoryFactory.Allocate(
                name: "SamName3",
                size: _ByteS.Length,
                protection: MemoryProtectionFlags.ExecuteReadWrite);
            _IAllocatedMemory.Write(0, _ByteS);

            delegateDel _delSumm = Marshal.GetDelegateForFunctionPointer<delegateDel>(_IAllocatedMemory.BaseAddress);
            answer = _delSumm(_A, _B);

            _IAllocatedMemory.Dispose();
            return answer;
        }

        public static double Generalization(int _A, int _B) // тут мы с помощью двух методов выше высчитываем среднюю оценку
        { return (WholePartNumber(_A, _B) + DecimalPartNumber(_A, _B) / (double)_B); }

        public static void Main(string[] args)
        {
            File.WriteAllText(path, ""); //обнуляем файл, чтобы при новом запуске приложение туда не записывалась лишняя информация
            List<Student> Group = new List<Student>();

            for (int i = 1; i <= 3; i++)
            {
                string Grd = "";
                Console.Write($"Введите фамилию студента №{i}: ");
                string sn = Convert.ToString(Console.ReadLine());
                string surname = sn.Substring(0, 1).ToUpper() + sn.Substring(1);

                if (Regex.IsMatch(surname, @"^[a-zA-Z]+$") || Regex.IsMatch(surname, @"^[а-яА-Я]+$")) //проверяем, что это именно слово, а не набор символов с цифрами 
                {
                    Random rnd = new Random();
                    int kolvo = rnd.Next(1, 11);
                    for (int j = 0; j < kolvo; j++)
                    {
                        int grades = rnd.Next(2, 6);
                        Grd += Convert.ToString(grades) + ",";
                    }
                    Grd = Grd.Remove(Grd.LastIndexOf(','));
                    Student student = new Student(surname, Grd);
                    Group.Add(student);
                }
                else
                {
                    Console.WriteLine("Введен неверный формат данных, повторите ввод\n");
                    i--;
                }
            }

            Console.WriteLine("\n\tИНФОРМАЦИЯ О СТУДЕНТАХ\n");  
            List<double> ArGrade = new List<double>();
            int kolvoHorosh = 0;

            for (int i = 0; i < 3; i++)
            {
                ArGrade.Add(Math.Round(Generalization(Group[i].Summ(), Group[i].AccessGrade().Count()), 2));
                Group[i].WriteThis();
                Console.WriteLine("\n\tСумма оценок: " + Group[i].Summ());
                File.AppendAllText(path, "\n\tСумма оценок: " + Group[i].Summ() + "\n");
                Console.WriteLine("\tСредняя оценка: " + ArGrade[i]);
                File.AppendAllText(path, "\tСредняя оценка: " + ArGrade[i] + "\n");
            }

            for (int i = 0; i < 3; i++)
            {
                if (ArGrade[i] > 3.5)
                {
                    kolvoHorosh++;
                }
            }
            Console.WriteLine("\n\n\tКачественная успеваемость: " + high_Perfomance(3, kolvoHorosh * 100) + "%");
            File.AppendAllText(path, "\n\n\tКачественная успеваемость: " + high_Perfomance(3, kolvoHorosh * 100) + "%\n\n\n");
            Console.WriteLine("\n");

            for (int i = 0; i < 3; i++) 
            {
                List<int> fivemark = new List<int>();
                int summ = 0;
                File.AppendAllText(path, "Студент " + Group[i].surname() + ' ');

                File.AppendAllText(path, "оценки за 5 работ : ");

                for (int y = 0; y < 5; y++)
                {
                    try // записываем 5 оценок. если оцеенок не хватает с помощью обработчика ставил прочерк
                    {
                        File.AppendAllText(path, Group[i].AccessGrade()[y] + " ");
                        fivemark.Add(Group[i].AccessGrade()[y]);
                        summ += Group[i].AccessGrade()[y];
                    }
                    catch
                    {
                        File.AppendAllText(path, "- ");

                    }
                }
                File.AppendAllText(path, ";\tCредняя оценка студента : ");
                File.AppendAllText(path, Math.Round(Generalization(summ, fivemark.Count()), 2) + "\n");//сердняя оценка студеннта за 5 оценок


            }




            Console.ReadLine();
        }
    }
}
