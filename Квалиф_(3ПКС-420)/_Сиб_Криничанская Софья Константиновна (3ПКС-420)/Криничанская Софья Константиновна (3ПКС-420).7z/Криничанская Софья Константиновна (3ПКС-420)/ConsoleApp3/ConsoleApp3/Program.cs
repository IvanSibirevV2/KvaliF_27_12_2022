﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.IO;

namespace ConsoleApp3
{
    class Student
    {
        // импорт dll(функция percent_knowledge)
        [DllImport(@"C:\Users\krini\OneDrive\Документы\Практика ПМ01\ConsoleApp3\ConsoleApp3\Debug\function.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern double percent_knowledge(int five_and_four_marks_count, int num_of_student);

        // импорт dll(функция sum_of_marks)
        [DllImport(@"C:\Users\krini\OneDrive\Документы\Практика ПМ01\ConsoleApp3\ConsoleApp3\Debug\function.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int sum_of_marks(int[] array_marks, int size_array);

        // импорт dll(функция avg_of_marks)
        [DllImport(@"C:\Users\krini\OneDrive\Документы\Практика ПМ01\ConsoleApp3\ConsoleApp3\Debug\function.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern double avg_of_marks(int[] array_marks, int size_array);

        private string Surname { get; set; }
        private string Marks { get; set; }
        private static int count_student = 0;
        private static List<int> AllMarks = new List<int>();
        private static List<string> AllSurname = new List<string>();
        private static List<string> AllMarksString = new List<string>();

        // первый конструктор Студент(Фамилия)
        public Student(string surname)
        {
            Surname = surname;
            AllSurname.Add(Surname);
            List<int> marks = new List<int>();           
            Random random = new Random();
            int num_marks = random.Next(1, 10);

            for (int i = 0; i < num_marks; i++)
            {
                marks.Add(random.Next(2, 5));
            }
            Marks = string.Join(", ", marks);
            AllMarksString.Add(Marks);
            for (int i = 0; i < marks.Count; i++)
            {
                AllMarks.Add(marks[i]);
            }
            count_student++;
        }

        // первый конструктор Студент(Фамилия, Оценки)
        public Student(string surname, string marks)
        {
            try
            {
                count_student++;
                Surname = surname;
                AllSurname.Add(Surname);
                Marks = marks;
                AllMarksString.Add(Marks);
                var khow_marks = Marks.Split(',').Select(x => int.Parse(x)).ToList();
                for (int i = 0; i < khow_marks.Count; i++)
                {
                    AllMarks.Add(khow_marks[i]);
                }             
            }
            catch
            {
                Console.WriteLine($" В строке \"Оценки\" у {AllSurname[count_student - 1]} ошибка\n\n");

            }
        }

        // функция, печатающая всю информацию о студенте
        public void PrintInfo()
        {            
            Console.WriteLine($" Фамилия: {Surname}\n Оценки: {Marks}\n Сумма оценок: {SumMarks()}\n Средний балл: {AVGMarks()}\n\n\n");          
        }

        // функция, возвращающая процент качества знаний
        public static string PercentKhowQuality()
        {
            int five_and_four_marks_count = AllMarks.Where(x => x == 5 || x == 4).Count();          
            double num = percent_knowledge(five_and_four_marks_count, count_student);
            string res = "\n Качество знаний: " + num.ToString() + "%";
            return res;
        }

        // функция, возвращающая сумму оценок конкретного студента (Assembler)
        // в противном случае (если в вооде оценок не встретилось чисел или встретилось не число в последовательности) возвращает -1
        private int SumMarks()
        {
            try
            {
                int[] marks = Marks.Split(',').Select(x => int.Parse(x)).ToArray();
                return sum_of_marks(marks, marks.Length);
            }
            catch (Exception)
            {
                Console.WriteLine(" В строке Оценки ошибка");
                return -1;
            }
        }

        // функция, возвращающая средний балл конкретного студента (Assembler)
        // в противном случае (если в вооде оценок не встретилось чисел или встретилось не число в последовательности) возвращает -1
        private double AVGMarks()
        {
            try
            {
                int[] marks = Marks.Split(',').Select(x => int.Parse(x)).ToArray();
                return avg_of_marks(marks, marks.Length);
            }
            catch (Exception)
            {
                return -1;
            }
        }

        // функция создающая файл
        //файл сохраняется в папке с проектом (ConsoleApp3-->bin-->Debug-->Students.txt)
        public static void GetFile()
        {
            File.Create("Students.txt").Close();

            FileStream stream = new FileStream(@"Students.txt", FileMode.Open, FileAccess.Write);
            StreamWriter writer = new StreamWriter(stream);
            int copy_i = 0;
            try
            {               
                for (int i = 0; i < count_student; i++)
                {
                    writer.WriteLine($" Фамилия: {AllSurname[i]}\n Оценки: {AllMarksString[i]}\n Сумма оценок: {sum_of_marks(AllMarksString[i].Split(',').Select(x => int.Parse(x)).ToArray(), AllMarksString[i].Split(',').Count())}\n Средний балл: {avg_of_marks(AllMarksString[i].Split(',').Select(x => int.Parse(x)).ToArray(), AllMarksString[i].Split(',').Count())}\n\n\n");
                    copy_i++;
                }

                writer.WriteLine(PercentKhowQuality());
            }
            catch(Exception)
            {
                writer.WriteLine($" Ошибка при вводе данных у студента {AllSurname[copy_i]}");
            }
            writer.Close();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // создание коллекции экземляров класса Student 
            List<Student> students = new List<Student>();

            // добавление в коллекцию трех экземлятор класса Student
            students.Add(new Student("Криничанская", "5, 5, 5, 3, 2, 5, 4"));
            students.Add(new Student("Борушко", "5, 5, 4, 3, 4, 5, 5, 3, 5, 5"));
            students.Add(new Student("Дронникова", "5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5"));

            // вывод на экран информации о каждом студенте
            for (int i = 0; i < students.Count; i++)
            {
                students[i].PrintInfo();
            }

            // вызов функции, которая создает файл в папке с проектом
            Student.GetFile();

            // вывод на экран информации о качестве знаний учащихся
            Console.WriteLine(Student.PercentKhowQuality());

            Console.ReadLine();
        }
    }
}
