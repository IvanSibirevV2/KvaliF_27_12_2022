#define gd _declspec(dllexport) 

extern "C"
{
	gd int sum(int a, int b)
	{
		return a + b;
	}
}