﻿#include <Windows.h>
#include <iostream>
#include <ctime>
#include <cmath>
#include <string>
#include <fstream>
#include <vector>
using namespace std;

class Tourist {
public:
    string surname, km;
    Tourist(string _surname) {
        surname = _surname;
    }
    Tourist(string _surname, string  _km) {
        surname = _surname;
        km = _km;
    }

    void showKm() {                                                  //В этом методе я вывожу пройденный путь туриста
        cout << "Пройденный путь " + surname << " равен " << km;
        for (int i = 0; i < km.size(); i ++) {
            if (km[i] != ',') {
                cout << km[i];
                if (i < km.size() - 2) {
                    cout << ',';
                }
            }
        }
    }
};



int getRandomNum(int min, int max) //метод для генерации рандомных числел в заданном диапазоне
{
    int range = max - min + 1;
    return rand() % range + min;
}

int getKmSum(int kmToSum[], int len) { //с помощью ассемблерной вставки возвращаю сумму всех маршрутов туриста
    int res = 0;
    __asm {
        mov ecx, len
        mov esi, kmToSum
        cycl:
            mov eax,[esi]
                push ecx
                add res,eax
                pop ecx
                add esi, 4
                loop cycl
    }
    return res;
}



int main()
{
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    int kmCount;
    ofstream myfile("primer.txt");//объект класса, для записи текста в файл
    string surname, km;
    vector<Tourist> tourist;
    for (int i = 0; i < 3; i++) {
        srand((int)time(0));
        int kmCount = getRandomNum(1, 10);
        cout << "Введите фамилию туриста №" << i + 1 << ":"; cin >> surname;
        km = "";
        int kmToSum[10];
        for (int j = 0; j < kmCount; j++) {
            int range = getRandomNum(1, 40);
            km += to_string(range) + ',';
            kmToSum[j] = range;
        }   
        tourist.push_back(Tourist(surname, km)); //записываю данные в конец динамического массива
        tourist.back().showKm(); //вывожу последний элемент динамического массива
        float avgKm = getKmSum(kmToSum, kmCount) / (float)kmCount;
        cout << " Средний маршрут: " << avgKm << endl;
        myfile << surname << " " << km << "Средний маршрут: " << avgKm << endl << endl;
    }
    myfile.close(); //закрываю запись в файл
}
