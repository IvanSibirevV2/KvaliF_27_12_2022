﻿using System;
using System.Collections.Generic;

namespace Task1
{
    // Класс Студент
    public class Student
    {
        public string LastName { get; set; } // Фамилия
        public List<int> Grades { get; set; } // Коллекция оценок

        public Student(string lastName) // конструктор с фамилией
        {
            LastName = lastName; 
            Grades = new List<int>();
        }

        public Student(string lastName,string grades) // конструктор с фамилией и оценками в виде строки
        {
            LastName = lastName;
            Grades = new List<int>();
            try
            {
                string[] gradesSplit = grades.Split(','); // разделяем строку на массив строк по запятой
                for (int i = 0; i < gradesSplit.Length; i++) // итерируем массив строк
                {
                    Grades.Add(int.Parse(gradesSplit[i])); // Добавляем в коллекцию оценок текущий элемент массива,
                                                           // предварительно превращая его в число с помощью int.Parse()
                }
            }catch (FormatException) // поскольку у нас в этом участке кода может быть ошибка, обрабатываем ее
            {
                Console.WriteLine("Ошибка в строке с оценками, строка должна состоять из чисел разделенных запятой\n" +
                    "Коллекция не заполнена.");
            } 
            
        }

        public double getAvgGrade() // Возвращает среднюю оценку
        {
            double sum = 0;
            for(int i = 0; i < Grades.Count; i++)
            {
                sum += Grades[i];
            }
            return sum / Grades.Count;
        }
       
        public override string ToString() // переопределили метод ToString чтобы вывести информацию о студенте в виде строки
        {
            // строку из фамилии и списка оценок
            // список оценок генерируем с помощью String.Join() этот метод вернет массив что мы передавали ему, в виде строки
            
            return String.Format("{0}:{1}", LastName, String.Join(",", Grades.ToArray()));
        }
    }
}
