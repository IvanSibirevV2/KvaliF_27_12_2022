﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Task1;

class TestClass 
{
    static void Main(string[] args) 
    {
        List<Student> students = new List<Student>(); // создаем коллекцию обьектов студент

        Random rnd = new Random(); // создаем обьект генератора случ. чисел


      
            Student student = new Student("Иванов"); // создаем через конструктор с одним параметром

            for(int j= 0; j < rnd.Next(2,11); j++) // Next(2,11) значит что мы получим случайное число в диапазоне [2,11) 11 не включительно
            {
                student.Grades.Add(rnd.Next(2,6));
            }
            students.Add(student); // добавляем студента в коллекцию
        

             Student student2 = new Student("Касаткина"); // создаем через конструктор с одним параметром

             for (int j = 0; j < rnd.Next(2, 11); j++) // Next(2,11) значит что мы получим случайное число в диапазоне [2,11) 11 не включительно
             {
                student2.Grades.Add(rnd.Next(2, 6));
             }
             students.Add(student2); // добавляем студента в коллекцию


             Student student3 = new Student("Лазарев"); // создаем через конструктор с одним параметром

             for (int j = 0; j < rnd.Next(2, 11); j++) // Next(2,11) значит что мы получим случайное число в диапазоне [2,11) 11 не включительно
             {
                 student3.Grades.Add(rnd.Next(2, 6));
             }
            students.Add(student3); // добавляем студента в коллекцию


        //Теперь выводим все обьекты в цикле
        for (int i = 0; i < students.Count; i++)
        {
            Console.WriteLine(students[i]);
        }

        // Теперь распечатаем студентов в файл а также их среднюю оценку с помощью отдельного метода
        SaveToFile(students);
    }


    private static void SaveToFile(List<Student> students)
    {
        // запись в файл
        using (FileStream fstream = new FileStream("students.txt", FileMode.OpenOrCreate))
        {
            for (int i = 0; i < students.Count; i++)
            {
                string temp = students[i].ToString() + ", средняя оценка: " + students[i].getAvgGrade()+"\n";
                // преобразуем строку в байты
                byte[] buffer = Encoding.Default.GetBytes(temp);
                // запись массива байтов в файл
                fstream.Write(buffer, 0, buffer.Length);
            }
            Console.WriteLine("Информация записана в файл students.txt");
        }
    }

}