﻿using Studentt;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Studentt
{
   //создаём класс Student
    class Student
    {
        // поля для хранения фамилии и оцено
        private string surname;
        private List<int> grades;

        //  доступ к фамилии
        public string Surname { get => surname; }

        //  доступ к коллекции
        public List<int> Grades { get => grades; }

        // Конструктор для создания ученика с фамилией 
        public Student(string surname)
        {
            this.surname = surname;
            this.grades = new List<int>();
        }

      
       
        //  метод для возврата списка целых чисел через запятую
        private List<int> ParseGrades(string grades)
        {
            try
            {
                
                return grades.Split(',').Select(int.Parse).ToList();
            }
            catch (FormatException)
            {
                
                return new List<int>();
            }
        }

        // метод для вычисления суммы всех оценок
        public int CalculateTotal()
        {
            return grades.Sum();
        }

        // метод расчета средней оценки


        public double CalculateAverage()
        {
            
            if (grades.Count == 0)
            {
                return 0;
            }

            return (double)CalculateTotal() / grades.Count;
        }
    }

}

class Program
{
    static void Main(string[] args)
    {

        List<Student> students = new List<Student>();
        
        students.Add(new Student("Болоцкий"));
        students.Add(new Student("Краснянская"));
        students.Add(new Student("Назиров"));

        Random random = new Random();

        foreach (Student student in students)
        {
            
            for (int i = 0; i < random.Next(1, 11); i++)
            {
                student.Grades.Add(random.Next(2, 6));
            }
        }
        foreach (Student student in students)
        {

            
            Console.WriteLine("Оценки для студента " + student.Surname + ": " + string.Join(", ", student.Grades));
            Console.WriteLine("средняя арифмитическая оценок: " + Math.Round(student.CalculateAverage(), 2));
            try
            {

                // вывод оценок и среднего ариф  в текстовый документ
                FileInfo fileInfo = new FileInfo(@"C:\c++\Bolockiy.txt");
                StreamWriter sw = fileInfo.AppendText();
                
                sw.WriteLine("Оценки для студента " + student.Surname + ": " + string.Join(", ", student.Grades));
                sw.WriteLine("средняя арифметическая оценок: " + Math.Round(student.CalculateAverage(), 2));
              

                sw.Close();

            }
            
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }

        }

        // подсчёт количества  5 и 4 среди всех учащихся,а также подсчёт всех оценок 
        int numFives = students.Sum(student => student.Grades.Count(grade => grade == 5));
        int numFours = students.Sum(student => student.Grades.Count(grade => grade == 4));
        int numFours1 = students.Sum(student => student.Grades.Count());
       
        double percentage = (numFives + numFours) * 100 / numFours1;

        
        Console.WriteLine("Качественная успеваемость: " + percentage + "%");
       
        Console.ReadLine();
    }
}
