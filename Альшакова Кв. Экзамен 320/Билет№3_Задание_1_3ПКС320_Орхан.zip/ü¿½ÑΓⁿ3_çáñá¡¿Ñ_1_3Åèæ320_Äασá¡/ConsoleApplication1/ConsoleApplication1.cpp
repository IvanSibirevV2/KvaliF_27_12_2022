﻿#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <Windows.h>
#include <vector>
#include <cmath>
using namespace std;

class Tourist
{
public:
    string surname, distance1;
    int distance[6];

    Tourist(string srnm) // конструктор по умолчанию 
    {
        surname = srnm; //передается значение фамилии
    }

    Tourist(string srnm, string distance2)
    {
        surname = srnm; //передается значение фамилии
        distance1 = distance2;
    }
};

int random_for_way()
{
    return 1 + rand() % 40; // случайное число от 1 до 40 (пройденный маршрут в км)
}

string km_tostring(Tourist tourist) // функция для записи маршрута
{

    string str = "";

    for (int i = 0; i < 6; i++)
    {
        str += to_string(tourist.distance[i]); 
        if (i != 5)
        {
            str += ", ";
        }
        else
        {
            str += ";";
        }
    }
    return str;

}

void output_info(Tourist tourist) // вывод информации о маршруте каждого туриста
{
    cout << tourist.surname;
    cout << " " << km_tostring(tourist);
    cout << endl;
}

double average(Tourist tourist) // рассчет суммы всех маршрутов для каждого туриста 
{
    double average;
    unsigned int sum = 0;
    __asm
    {
        xor eax, eax 
        xor ecx, ecx 
        mov ecx, 0
        metka:
        add eax, tourist.distance[ecx * 4]
            inc ecx 
            cmp ecx, 6 
            jl metka 

            mov sum, eax
    }
    average = (double)sum / 6;
    return average;
}

int main() // функция для вывода общей информации (фамилия, все маршруты и средний маршрут каждого туриста) 
{

    srand((unsigned int)time(NULL));
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    string name1, name2, name3;
    cout << "Введите фамилию первого туриста: "; cin >> name1;
    cout << "Введите фамилию второго туриста: "; cin >> name2;
    cout << "Введите фамилию третьго туриста: "; cin >> name3;
    Tourist tur1(name1), tur2(name2), tur3(name3);

    for (int i = 0; i < 6; i++)
    {
        tur1.distance[i] = random_for_way();
        tur2.distance[i] = random_for_way();
        tur3.distance[i] = random_for_way();
    }
    output_info(tur1);
    output_info(tur2);
    output_info(tur3);
    double avg1 = average(tur1);
    double avg2 = average(tur2);
    double avg3 = average(tur3);
    cout << endl;
    cout << tur1.surname << endl;
    cout << "Ср. маршрут: " << round(avg1 * 100) / 100 << endl;
    cout << " " << endl;
    cout << tur2.surname << endl;
    cout << "Ср. маршрут: " << round(avg2 * 100) / 100 << endl;
    cout << " " << endl;
    cout << tur3.surname << endl;
    cout << "Ср. маршрут: " << round(avg3 * 100) / 100 << endl;
    cout << " " << endl;
    std::ofstream out;
    out.open("C:/Users/206959/Documents/list.txt");
    if (out.is_open())
    {
        out << tur1.surname << endl;
        out << "Все маршруты: " << km_tostring(tur1) << endl;
        out << "Ср. маршрут: " << round(avg1 * 100) / 100 << endl;
        out << " " << endl;
        out << tur2.surname << endl;
        out << "Все маршруты: " << km_tostring(tur2) << endl;
        out << "Ср. маршрут: " << round(avg2 * 100) / 100 << endl;
        out << " " << endl;
        out << tur3.surname << endl;
        out << "Все маршруты: " << km_tostring(tur3) << endl;
        out << "Ср. маршрут: " << round(avg3 * 100) / 100 << endl;
        out << " " << endl;
    }
    system("pause");

}