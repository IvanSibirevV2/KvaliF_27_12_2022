﻿#include <iostream> //Ввод.Вывод
#include <string> //Строки
#include <cstdlib> //Для функции srand и rand
#include <ctime> //для функции time()
#include <fstream>  //Для записи в файл
#include <Windows.h>
#include <cmath>
using namespace std;


class Worker
{
public:
    string surname, zp;
    int zp_mas[8];
    Worker(string surName)
    {
        surname = surName;
    }
    Worker(string surName, string zP)
    {
        surname = surName;
        zp = zP;
    }
};


string zp(Worker worker)
{
    string zp = "";
    for (int i = 0; i < 8; i++) 
    {
        zp += to_string(worker.zp_mas[i]);
        if (i != 7) //Вывод разграничительных знаков 
        {
            zp += ", ";
        }
        else
        {
            zp += ";";
        }
    }
    return zp;

}

void info_out(Worker worker) //функция выводящая информацию о сотруднике на экран
{
    cout << worker.surname << ": ";
    cout << zp(worker) << endl;
}   


double average(Worker worker) //Расчет сумм для вычисления среднего значения
{
    double avg;
    int sum = 0; //Целая часть
    __asm
    {
        xor eax, eax
        xor ecx, ecx
        mov ecx, 0
        metka:
        add eax, worker.zp_mas[ecx * 4]
            inc ecx
            cmp ecx, 8
            jl metka
            xor bx, bx
            xor cx, cx
            mov sum, eax
    }
    avg = (double)sum / 8;
    cout << round(avg * 100) / 100 << endl;
    return avg;
}
int main()
{
    srand((unsigned int)time(NULL));
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    string sur1, sur2, sur3;
    //Ввод фамилий сотрудников
    cout << "Введите фамилию первого сотрудника: "; cin >> sur1;
    cout << "Введите фамилию второго сотрудника: "; cin >> sur2;
    cout << "Введите фамилию третьего сотрудника: "; cin >> sur3;
    Worker worker1(sur1), worker2(sur2), worker3(sur3);
    //Вывод зарплат сотрудников 
    for (int i = 0; i < 8; i++)
    {
        worker1.zp_mas[i] = 40000 + rand() % 20000;
        worker2.zp_mas[i] = 40000 + rand() % 20000;
        worker3.zp_mas[i] = 40000 + rand() % 20000;
    }
    info_out(worker1);
    info_out(worker2);
    info_out(worker3);
    double avg1 = average(worker1);
    double avg2 = average(worker2);
    double avg3 = average(worker3);
    //Вывод средних зарплат сотрудников
    cout << endl;
    cout << "Средняя зарплата " + worker1.surname + "а: " << round(avg1 * 100) / 100 << endl;
    cout << "Средняя зарплата " + worker2.surname + "а: " << round(avg2 * 100) / 100 << endl;
    cout << "Средняя зарплата " + worker3.surname + "а: " << round(avg3 * 100) / 100 << endl;
    ofstream out; //поток для записи файла
    out.open("C:\\Users\\206935\\source\\repos\\ConsoleApplication1\\ConsoleApplication1\\Сотруднки__ЗП.txt"); //открываем файл для записи
    if (out.is_open())
    {
        out << worker1.surname << endl;
        out << "Зарплаты за 8 месяцев: " << zp(worker1) << endl;
        out << "Средний размер зарплаты: " << round(avg1 * 100) / 100 << endl << endl;
        out << worker2.surname << endl;
        out << "Зарплаты за 8 месяцев: " << zp(worker2) << endl;
        out << "Средний размер зарплаты: " << round(avg2 * 100) / 100 << endl << endl;
        out << worker3.surname << endl;
        out << "Зарплаты за 8 месяцев: " << zp(worker3) << endl;
        out << "Средний размер зарплаты: " << round(avg3 * 100) / 100 << endl;
    }
    system("pause");
    return 0;
}

