﻿#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <cmath>
#include <Windows.h>

using namespace std;


class Tourist
{
public:
    string name, distance;
    int distance_array[7];
    Tourist(string surname)
    {
        name = surname;
    }
    Tourist(string surname, string dist)
    {
        name = surname;
        distance = dist;
    }
};

int random()
{
    return 1 + rand() % 40;
}

string Int_String(Tourist tourist)
{
    string stroka = "";
    for (int i = 0; i < 7; i++)
    {
        stroka += to_string(tourist.distance_array[i]);
        if (i != 6)
        {
            stroka += ", ";
        }
        else
        {
            stroka += ";";
        }
    }
    return stroka;

}

void output(Tourist tourist)
{
    cout << "Все маршруты туриста " << tourist.name;
    cout << "- " << Int_String(tourist);
    cout << endl;
}

double avg(Tourist tourist)
{
    double avg;
    unsigned int sum = 0;
    __asm
    {
        xor eax, eax
        xor ecx, ecx
        mov ecx, 0
        metka:
        add eax, tourist.distance_array[ecx * 4]
            inc ecx
            cmp ecx, 7
            jl metka
            xor bx, bx
            xor cx, cx
            mov sum, eax
    }
    avg = (double)sum / 7;
    return avg;
}

int main()
{
    srand((unsigned int)time(NULL));
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    string name1, name2, name3;
    cout << "Введите фамилию первого туриста: "; cin >> name1;
    cout << "Введите фамилию второго туриста: "; cin >> name2;
    cout << "Введите фамилию третьго туриста: "; cin >> name3;
    Tourist tourist1(name1), tourist2(name2), tourist3(name3);
    for (int i = 0; i < 7; i++)
    {
        tourist1.distance_array[i] = random();
        tourist2.distance_array[i] = random();
        tourist3.distance_array[i] = random();
    }
    output(tourist1);
    output(tourist2);
    output(tourist3);
    double avg1 = round(avg(tourist1)* 100) / 100;
    double avg2 = round(avg(tourist2) * 100) / 100;
    double avg3 = round(avg(tourist3) * 100) / 100;
    cout << endl;
    cout << "Турист " + tourist1.name << "- средний маршрут " << avg1 << endl;
    cout << "Турист " + tourist2.name << "- средний маршрут " << avg2 << endl;
    cout << "Турист " + tourist3.name << "- средний маршрут " << avg3 << endl;
    std::ofstream out;
    out.open("C:\\Алиев\\Туристы.txt");
    if (out.is_open())
    {
        out << tourist1.name << endl;
        out << "Все маршруты: " << Int_String(tourist1) << endl;
        out << "Средняя длина маршрута: " << avg1 << endl << endl;
        out << tourist2.name << endl;
        out << "Все маршруты: " << Int_String(tourist2) << endl;
        out << "Средняя длина маршрута: " << avg2 << endl << endl;
        out << tourist3.name << endl;
        out << "Все маршруты: " << Int_String(tourist3) << endl;
        out << "Средняя длина маршрута: " << avg3 << endl << endl;
    }
    system("pause");
    return 0;
}


