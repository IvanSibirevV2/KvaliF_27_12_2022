﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using ControlzEx.Standard;

namespace bilet_2
{
    class Sotrudnik
    {
        public string name;
        public List<int> zp = new List<int>();   //зарплаты

        public Sotrudnik() { }
        private static Random rand = new Random();
        public Sotrudnik(string Name)
        {
            this.name = Name;
            int e = rand.Next(1, 11);  //рандом для определения кол-ва зарплат
            for (int i = 0; i < e; i++)
            {
                this.zp.Add(rand.Next(40000, 60001));   //рандом для определения номинала зарплат
            }
        }

        public Sotrudnik(string Name, params int[] Zp)
        {
            this.name = Name;
            this.zp = Zp.ToList();
        }

        public Sotrudnik Output()   //метод для вывода информации
        {
            Console.Write("Фамилия сотрудника: " + this.name + "\nЕго зарплаты: ");
            foreach (int a in this.zp)
            {
                Console.Write(a + "; ");
            }
            Console.WriteLine("\n");
            return this;
        }

        public int Sred()   //расчет средней зарплаты для конкретного сотрудника
        {
            int summ = 0;
            int count = this.zp.Count();
            for (int i = 0; i < count; i++)
            {
                summ += this.zp[i];
            }
            return summ / count;
        }
        
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Sotrudnik> A1 = new List<Sotrudnik>();  //список сотрудников
            var rnd = new Random();
            string naame;
            int t = 1;
            while (t < 4)   //проверка на условие - чтобы в фамилии не было цифр
            {
                Console.Write($"Введите фамилию {t} сотрудника: ");
                naame = Console.ReadLine();
                for (int l = 0; l < naame.Length; l++)
                {
                    if (naame[l] >= '0' && naame[l] <= '9')
                    {
                        Console.WriteLine("В фамилии не должны содержаться цифры");
                        break;
                    }
                    else
                    {
                        A1.Add(new Sotrudnik(naame));
                        t++;
                        break;
                    }
                }
            }
            Console.WriteLine("-------------------\n");

            for (int i = 0; i < A1.Count; i++)   //выводим информацию о сотрудниках
            {
                A1[i].Output();   
            }

            Console.WriteLine("\n!Чтение информации из файла!\n");   //с этого блока происходит запись информации в файл, а далее - вывод с файла в консоль
            string tofile = "";
            for (int h = 0; h < A1.Count; h++)
            {
                if (A1[h].zp.Count >= 6)
                {
                    tofile = tofile + A1[h].name + ", зарплата за 6 месяцев: " + A1[h].zp[0] + ", " + A1[h].zp[1] + ", " + A1[h].zp[2] + ", " + A1[h].zp[3] + ", " + A1[h].zp[4] + ", " + A1[h].zp[5] + ", средняя зарплата " + A1[h].Sred() + "\n";
                }
                else
                {
                    tofile = tofile + A1[h].name + ", зарплата за 6 месяцев: ";
                    for (int j = 0; j < A1[h].zp.Count; j++)
                    {
                        tofile = tofile + A1[h].zp[j] + ", ";
                    }
                    tofile = tofile + ", средняя зарплата " + A1[h].Sred() + "\n";
                }
            }
            string pat = @"D:\проба2\exp.txt";
            File.WriteAllText(pat, tofile);
            string name = File.ReadAllText(pat);
            Console.WriteLine(name);

        }
    }
}
