﻿#include <Windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
using namespace std;

class Student
{
	string surname, marks;
public:
	Student(string _surname)
	{
		surname = _surname;
	}
	Student(string _surname, string _marks)
	{
		surname = _surname;
		marks = _marks;
	}
	void ShowMarks()
	{
		cout << "-----------------------------\n";
		cout << "Оценки студента " + surname << endl;
		for (int i = 0; i < marks.size(); i++)
		{
			if (marks[i] != ',')
			{
				cout << marks[i];
				if (i < marks.size() - 2)
				{
					cout << ",";
				}
			}
		}
		cout << "\n-----------------------------\n";
	}
};
int getNum(int min, int max)
{
	int range = max - min + 1;
	srand((unsigned int)time(NULL));
	Sleep(250);
	return min + rand() % range;
}
int getSum(int marks[], int len)
{
	int res = 0;
	__asm
	{
		mov ecx, len
		mov esi, marks
		cycl:
		mov eax, [esi]
			push ecx
			add res, eax
			pop ecx
			add esi, 4
			loop cycl
	}
	return res;
}
int Performance(int goodamount, int greatamount, int StudentsAmount)
{
	int res = 0;
	__asm
	{
		mov eax, goodamount
		add eax, greatamount
		div StudentsAmount
		mov res, eax
	}
	return res;
}
int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	vector<Student> students;
	string surname, marks;
	string amount;
	int goodgreatMarksAmount = 0;
	int goodamount = 0;
	int greatamount = 0;
	ofstream myfile("Students.txt");
	for (int i = 0; i < 3; i++)
	{
		int marksC = getNum(1, 10);
		cout << "Введите фамилию " << i + 1 << "-ого студента: "; cin >> surname;
		marks = "";
		int marksSum[10];
		for (int j = 0; j < marksC; j++)
		{
			int mark = getNum(2, 5);
			marks += to_string(mark) + ',';
			marksSum[j] = mark;
			if (mark == 4)
			{
				goodamount++;
			}
			if (mark == 5)
			{
				greatamount++;
			}
			Sleep(100);
		}
		
		students.push_back(Student(surname, marks));
		students.back().ShowMarks();
		float avgMark = getSum(marksSum, marksC) / (float)marksC;
		avgMark = floor(avgMark * 100.0) / 100.0;
		cout << "Средний балл: " << avgMark << endl << endl;
		myfile << surname << " " << marks << " Средний балл: " << avgMark << endl;
	}
	int perf = Performance(goodamount, greatamount, students.size());
	cout << "Итого вышло " << perf << "% качества знаний";
	myfile << "Итого вышло " << perf << "% качества знаний";
	myfile.close();
}