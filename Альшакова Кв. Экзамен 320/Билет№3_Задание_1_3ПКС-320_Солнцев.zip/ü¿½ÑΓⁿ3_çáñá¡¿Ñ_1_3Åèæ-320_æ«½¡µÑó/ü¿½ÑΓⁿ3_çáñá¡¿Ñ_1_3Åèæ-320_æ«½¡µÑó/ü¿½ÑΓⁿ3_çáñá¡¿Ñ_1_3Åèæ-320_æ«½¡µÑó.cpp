﻿#include <iostream> 
#include <string>
#include <cstdlib> //Для функций srand и rand
#include <fstream> //Для записи в файл
#include <Windows.h>
#include <cmath> //Для функции round
#include <ctime> //Для функции time

using namespace std;

class Tourist
{
public:
    string kilometr;
    string surname;//Фамилия туриста
    int kilometers[9]; //Массив маршрутов
    Tourist(string surname1)
    {
        surname = surname1;
    }
    Tourist(string surname1, string kilometr1)
    {
        surname = surname1;
        kilometr = kilometr1;
    }
};

int RandomNumbers() //Метод для получения случайных чисел
{
    return 1 + rand() % 40; //Функция, возвращающая случайные километры
}



string ToStringKilometers(Tourist tourist) //Метод для перевода значений в строку
{
    string str = "";
    for (int i = 0; i < 9; i++)
    {
        str += to_string(tourist.kilometers[i]); //Преобразование числа в строку
        if (i != 9 - 1)
        {
            str += ",";
        }

        else
        {
            str += ";";

        }

    }

    return str;

}

void OutputInfo(Tourist tourist) //Метод для вывода информации о туристе
{
    cout << tourist.surname << " ";
    cout << ToStringKilometers(tourist);
    cout << endl << "--------------------------------------";
    cout << endl;
}

double avg(Tourist tourist) //Подсчёт сумм для рассчёта средних значений
{
    double avg;
    unsigned int sum = 0;
    __asm
    {
        xor eax, eax
        xor ecx, ecx
        mov ecx, 0
        metka:
        add eax, tourist.kilometers[ecx * 4]
            inc ecx
            cmp ecx, 9
            jl metka
            xor bx, bx
            xor cx, cx
            mov sum, eax
    }
    avg = (double)sum / 9; //Вычисление среднего значения
    cout << round(avg * 100) / 100 << endl; //Вывод средних значений
    return avg;
}

int main()
{
    srand((unsigned int)time(NULL)); //Установка рандома для получения новых случайных чисел при каждом запуске программы
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    string sur1, sur2, sur3;
    cout << "Введите фамилию первого туриста: ";
    cin >> sur1;
    cout << "Введите фамилию первого туриста: ";
    cin >> sur2;
    cout << "Введите фамилию первого туриста: ";
    cin >> sur3;
    Tourist tourist1(sur1), tourist2(sur2), tourist3(sur3);

    for (int i = 0; i < 9; i++)
    {
        tourist1.kilometers[i] = RandomNumbers();
        tourist2.kilometers[i] = RandomNumbers();
        tourist3.kilometers[i] = RandomNumbers();
    }

    OutputInfo(tourist1);
    OutputInfo(tourist2);
    OutputInfo(tourist3);

    double avg1 = avg(tourist1);
    double avg2 = avg(tourist2);
    double avg3 = avg(tourist3);

    cout << "--------------------------------------" << endl;
    cout << tourist1.surname + " в среднем прошёл: " << round(avg1 * 100) / 100 << endl << "--------------------------------" << endl;
    cout << tourist2.surname + " в среднем прошёл: " << round(avg2 * 100) / 100 << endl << "--------------------------------" << endl;
    cout << tourist3.surname + " в среднем прошёл: " << round(avg3 * 100) / 100 << endl << "--------------------------------" << endl;

    ofstream file; //Поток для записи файла
    file.open("c:\\ExFile\\файл.txt"); //Открытие файла 
    if (file)
    {
        string division = "--------------------------------------";
        file << tourist1.surname << endl;
        file << "Пройденные километры: " << ToStringKilometers(tourist1) << endl;
        file << "Среднее пройденное расстояние: " << round(avg1 * 100) / 100 << endl;
        file << division << endl;
        file << tourist2.surname << endl;
        file << "Пройденные километры: " << ToStringKilometers(tourist2) << endl;
        file << "Среднее пройденное расстояние: " << round(avg2 * 100) / 100 << endl;
        file << division << endl;
        file << tourist3.surname << endl;
        file << "Пройденные километры: " << ToStringKilometers(tourist3) << endl;
        file << "Среднее пройденное расстояние: " << round(avg3 * 100) / 100 << endl;
        file << division << endl;
    }

    else
    {
        cout << "Ошибка при открытии файла!";
    }

    file.close();
    system("pause");
    return 0;
}
