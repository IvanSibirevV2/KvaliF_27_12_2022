﻿#include <iostream> 
#include <string>
#include <cstdlib>
#include <fstream>
#include <Windows.h>
#include <cmath> 
#include <ctime> 
#pragma warning(2:4235)

using namespace std;

class Tourist
{
    public:
        string km;
        string surname;
        
        int stages = 1 + rand() % 10; // рандом 1 - 10 (для выбора количества дней, когда турист был в дороге)
        int KmS[9]; 

        Tourist(string surname_)
        {
            surname = surname_;
        }
        Tourist(string surname_, string km1)
        {
            surname = surname_;
            km = km1;
        }
};


//
// рандом в диапазоне 1 - 40 
//

int SetRandValue() 
{
    return 1 + rand() % 40;
}


//
// функция для записи километров в файл
//
string ConvertIntToString(Tourist tourist) 
{
    string str = "";
    for (int i = 0; i < tourist.stages; i++)
    {
        str += to_string(tourist.KmS[i]); 
        if (i != tourist.stages - 1) str += ",";
        else str += ";"; // значений было последним
    }

    return str;
}

//
// функция вывода информации о том сколько уже прошел турист
//
void OutputInfo(Tourist tourist) 
{
    cout << tourist.surname << " already passed " << ConvertIntToString(tourist) << endl;
}


//
// ASM - вставка + рассчет средних значений
//
double FindAverageValue(Tourist tourist, int cnt) 
{
    double AverageValue;
    unsigned int sum = 0;

    __asm
    {
        mov ebx, cnt
        xor eax, eax
        xor ecx, ecx
        mov ecx, 0
        metka:
        add eax, tourist.KmS[ecx * 4]
            inc ecx
            cmp ecx, ebx
            jl metka
            xor bx, bx
            xor cx, cx
            mov sum, eax
    }

    return (double)sum / cnt;
}

int main()
{
    srand((unsigned int)time(NULL)); 
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    string surname_;
//
//  - работа с первым туристом - 
//
    // - заполнение информации
    cout << "Enter surname of the first student: ";
    cin >> surname_;
    Tourist first_tourist(surname_);

    for (int i = 0; i < 9; i++) first_tourist.KmS[i] = SetRandValue();
    OutputInfo(first_tourist);
    
    // - подсчет среднего значения
    double AverageValue_first = FindAverageValue(first_tourist, first_tourist.stages);
    cout << first_tourist.surname + " average distance: " << round(AverageValue_first * 100) / 100 << endl;
    cout << "--------------------------------------\n" << endl;

//
//  - работа со вторым туристом - 
//
    cout << "Enter surname of the second student: ";
    cin >> surname_;
    Tourist second_tourist(surname_);

    // - заполнение информации
    for (int i = 0; i < 9; i++) second_tourist.KmS[i] = SetRandValue();
    OutputInfo(second_tourist);

    // - подсчет среднего значения
    double AverageValue_second = FindAverageValue(second_tourist, second_tourist.stages);
    cout << second_tourist.surname + " average distance: " << round(AverageValue_second * 100) / 100 << endl;
    cout << "--------------------------------------\n" << endl;

//
//  - работа с тертьим туристом - 
//
    cout << "Enter surname of the third student: ";
    cin >> surname_;
    Tourist third_tourist(surname_);

    // - заполнение информации
    for (int i = 0; i < 9; i++) third_tourist.KmS[i] = SetRandValue();
    OutputInfo(third_tourist);

    // - подсчет среднего значения
    double AverageValue_third = FindAverageValue(third_tourist, third_tourist.stages);
    cout << third_tourist.surname + " average distance: " << round(AverageValue_third * 100) / 100 << endl;
    cout << "--------------------------------------\n" << endl;

//
// - запись в файл - 
//
    ofstream file;
    string division = "--------------------------------------";
    file.open("kvalif_exam_Chicherina_420.txt"); 
    if (file)
    {
        file << first_tourist.surname << endl;
        file << "Пройденные километры: " << ConvertIntToString(first_tourist) << endl;
        file << "Количиство дней в пути: " << first_tourist.stages << endl;
        file << "Среднее пройденное расстояние: " << round(AverageValue_first * 100) / 100 << endl;
        file << division << endl;
        file << second_tourist.surname << endl;
        file << "Пройденные километры: " << ConvertIntToString(second_tourist) << endl;
        file << "Количиство дней в пути: " << second_tourist.stages << endl;
        file << "Среднее пройденное расстояние: " << round(AverageValue_second * 100) / 100 << endl;
        file << division << endl;
        file << third_tourist.surname << endl;
        file << "Пройденные километры: " << ConvertIntToString(third_tourist) << endl;
        file << "Количиство дней в пути: " << third_tourist.stages << endl;
        file << "Среднее пройденное расстояние: " << round(AverageValue_third * 100) / 100 << endl;
        file << division << endl;
    }

    else
    {
        cout << "Ошибка при открытии файла!";
    }


    file.close();
    system("pause");
    return 0;
}
