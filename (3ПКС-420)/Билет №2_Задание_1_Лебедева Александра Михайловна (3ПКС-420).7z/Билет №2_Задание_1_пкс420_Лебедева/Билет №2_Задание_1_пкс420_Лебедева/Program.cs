﻿using System;
using System.Collections.Generic;
using System.Linq;
using Binarysharp.Assemblers.Fasm;
using Process.NET;
using Process.NET.Native.Types;
using System.Runtime.InteropServices;
using System.Security;
using System.IO;

namespace Билет__2_Задание_1_пкс420_Лебедева
{
	public class Worker	 //класс Сотрудник
	{
		public string Surname;		 //фамилия сотрудника
		public Dictionary<int, int> Month_salary = new Dictionary<int, int>();      //коллекция зарплат по номеру месяца

		public int summMounth_6 = 0; //зарплата за 6 месяцев
		public int avgSumm = 0; //средняя зарплата сотрудника

		public Worker (string surname)
		{
			Surname = surname;
		}

		public Worker(string surname, string str_salary)
		{
			Surname = surname;
			string[] str = str_salary.Split(',');

			for (int i = 0; i < str.Length; i++)
			{
				Month_salary.Add(i + 1, int.Parse(str[i]));
			}

			//сумма зарплаты сотрудника за 6 месяцев
			if (str.Length < 7)
			{
				for (int i = 0; i < str.Length; i++)
				{
					summMounth_6 += int.Parse(str[i]);
				}
			}
			else
			{
				for (int i = 0; i < 6; i++)
				{
					summMounth_6 += int.Parse(str[i]);
				}
			}
			//средняя зарплата сотрудника
			for (int i = 0; i < str.Length; i++)
			{
				avgSumm += int.Parse(str[i]);
			}
			avgSumm = avgSumm / str.Length;
		}
		public void Print() //метода вывода заполненной информации о сотруднике
		{
			Console.WriteLine("\n\tФамилия сотрудника: " + Surname);
			for (int i = 0; i < Month_salary.Count; i++)
				Console.WriteLine($"\t\t\tМесяц: {Month_salary.ElementAt(i).Key}\tЗарплата: {Month_salary.ElementAt(i).Value}");
		}

		public string write_File()
		{
			string file = $"Фамилия сотрудника: {Surname}\n\tЗарплата за 6 месяцев: {summMounth_6}\n\tСредняя зарплата сотрудника: {avgSumm}";
			return file;
		}
	}

	class Program
	{
		static void Main(string[] args)
		{
			Worker worker1 = new Worker("Капская", random_salary());
			worker1.Print();
			Worker worker2 = new Worker("Попов");
			worker2.Print();
			Worker worker3 = new Worker("Сибирев", random_salary());
			worker3.Print();



			string random_salary() //метод формирует зарплаты генератором случайных чисел и возвращает строкой, где каждая из зарплат перечисляется через запятую
			{
				Random rand = new Random();
				int n = rand.Next(1, 11); //количество полученных сотрудником зарплат в диапазоне от 1 до 10
				int[] mass_salary = new int[n];
				string str_salary;
				for (int i = 0; i < mass_salary.Length; i++)
				{
					mass_salary[i] = rand.Next(40000, 60001); //зарплата сотрудника в диапазоне от 40 000 до 60 000
				}
				str_salary = mass_salary.Select(a => a.ToString()).Aggregate((i, j) => i + "," + j); //преобразование массива зарплат в строку с разделителем ввиде запятой

				return str_salary;
			}

			//запись в файл фамилии сотрудников, зарплату за 6 месяцев и среднюю зарплату сотрудников
			using (StreamWriter writer = new StreamWriter("File.txt"))
			{
				writer.WriteLine(worker1.write_File());
				writer.WriteLine(worker2.write_File());
				writer.WriteLine(worker3.write_File());
			}
		}
	}
}
