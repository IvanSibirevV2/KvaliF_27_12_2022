﻿// Билет№3.cpp : 
#include <iostream> 
#include <string>
#include <cstdlib> //Для функций srand и rand
#include <fstream> //Для записи в файл
#include <Windows.h>
#include <cmath> //Для функции round
#include <ctime> //Для функции time
#include <fstream>

using namespace std;

class Tourist
{
public:
    string km;
    string surname;
    int routes[10]; //Массив маршрутов
    Tourist(string surname1)
    {
        surname = surname1;
    }
    Tourist(string surname1, string kilometr1)
    {
        surname = surname1;
        km = kilometr1;
    }
};

int RandomNumbers() //Метод для получения случайных чисел
{
    int way= 1 + rand() % 40;
    return way; //Функция, возвращающая случайные километры
}



string ToStringKilometers(Tourist tourist) //Метод для перевода значений в строку
{
    string str = "[";
    for (int i = 0; i < 10; i++)
    {
        str += to_string(tourist.routes[i]); //Преобразование числа в строку
        if (i<9)str += ", ";

    }
    str += ']';
    return str;
}

void OutputInfo(Tourist tourist) //Метод для вывода информации о туристе
{
    cout << "Турист " << tourist.surname << " ";
    cout << ToStringKilometers(tourist);
    cout << endl;
}

double avg(Tourist tourist) //Подсчёт сумм для рассчёта средних значений
{
    double avg;
    unsigned int sum = 0;
    __asm
    {
        xor eax, eax
        xor ecx, ecx
        mov ecx, 0
        metka:
        add eax, tourist.routes[ecx * 4]
            inc ecx
            cmp ecx, 9
            jl metka
            xor bx, bx
            xor cx, cx
            mov sum, eax
    }
    avg = (double)sum / 10; //Вычисление среднего значения
    return avg;
}

int main()
{
    srand((unsigned int)time(NULL)); //Установка рандома для получения новых случайных чисел при каждом запуске программы
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    string sur1, sur2, sur3;
    cout << "Введите фамилию первого туриста: ";
    cin >> sur1;
    cout << "Введите фамилию второго туриста: ";
    cin >> sur2;
    cout << "Введите фамилию третьего туриста: ";
    cin >> sur3;
    Tourist tourist1(sur1), tourist2(sur2), tourist3(sur3);

    for (int i = 0; i < 10; i++)
    {
        tourist1.routes[i] = RandomNumbers();
        tourist2.routes[i] = RandomNumbers();
        tourist3.routes[i] = RandomNumbers();
    }
    double avg1 = avg(tourist1);
    double avg2 = avg(tourist2);
    double avg3 = avg(tourist3);
    OutputInfo(tourist1);
    cout << tourist1.surname + " в среднем прошёл: " << round(avg1 * 100) / 100 << endl << "--------------------------------" << endl;
    OutputInfo(tourist2);
    cout << tourist2.surname + " в среднем прошёл: " << round(avg2 * 100) / 100 << endl << "--------------------------------" << endl;
    OutputInfo(tourist3);
    cout << tourist3.surname + " в среднем прошёл: " << round(avg3 * 100) / 100 << endl << endl;
    

    cout << "--------------------------------------" << endl << endl << endl << endl;
    
    
    

    ofstream file; //Поток для записи файла
    file.open("Итоговый_файл.txt"); //Открытие файла 
    if (file.is_open())
    {
        file << tourist1.surname << std::endl;
        file << "Все маршруты: " << ToStringKilometers(tourist1) << endl;
        file << "Среднее пройденное расстояние: " << round(avg1 * 100) / 100 << endl;
        file << "---------------------------" << endl;
        file << tourist2.surname << std::endl;
        file << "Все маршруты: " << ToStringKilometers(tourist2) << endl;
        file << "Среднее пройденное расстояние: " << round(avg2 * 100) / 100 << endl;
        file << "---------------------------" << endl;
        file << tourist3.surname << std::endl;
        file << "Все маршруты: " << ToStringKilometers(tourist3) << endl;
        file << "Среднее пройденное расстояние: " << round(avg3 * 100) / 100 << endl;
    }
    cout << "Хотите вывести данные из файла (1-да, 0-нет)";
    int answer;
    cin >> answer;
    if (answer) {
        string line;
        ifstream file1("Итоговый_файл.txt"); //Поток для чтения файла
        cout << "ЧТЕНИЕ ИЗ ФАЙЛА" << endl;
        if (file.is_open()) {
            while (getline(file1, line))
            {
                cout << line << endl;
            }
        }
    }
    cout << "ВЫПОЛНЕНИЕ ЗАКОНЧЕНО" << endl;
    
    file.close();
}
