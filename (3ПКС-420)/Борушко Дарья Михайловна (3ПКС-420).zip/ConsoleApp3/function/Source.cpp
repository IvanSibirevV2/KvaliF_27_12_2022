#define function _declspec(dllexport) 

extern "C"
{
	function int sum_of_marks(int array_marks[], int size_array)
	{
		int sum_of_marks = 0;

		_asm
		{
				mov eax, size_array
				mov ecx, 0
				lea ebx, [array_marks]
				mov edx, [ebx]
				add ecx, [edx]
				dec eax
				cmp eax, 0
				jz exit_

			cycle :
				dec eax
				add edx, 4
				add ecx, [edx]
				cmp eax, 0
				jnz cycle

			exit_ :
				mov sum_of_marks, ecx
		}
		return sum_of_marks;
	}

	function double avg_of_marks(int array_marks[], int size_array)
	{
		int a, b;

		_asm
		{
			mov eax, size_array
			mov ecx, 0
			lea ebx, [array_marks]
			mov edx, [ebx]
			add ecx, [edx]
			dec eax
			cmp eax, 0
			jz exit_

		cycle :
			dec eax
			add edx, 4
			add ecx, [edx]
			cmp eax, 0
			jnz cycle

		exit_ :
			mov edx, 0
			mov eax, ecx
			mov ebx, size_array
			div ebx

			mov a, eax
			mov eax, 100
			mul edx
			div ebx
			mov b, eax
		}
		return double(a * 100 + b) / 100;
	}

	function double percent_knowledge(int five_and_four_marks_count, int num_of_student)
	{
		int a, b;
		
		_asm
		{
			mov eax, five_and_four_marks_count
			mov edx, 0
			mov ebx, num_of_student
			div ebx

			mov a, eax
			mov eax, 100
			mul edx
			div ebx
			mov b, eax
		}
		return double(a * 100 + b) / 100;
	}
}